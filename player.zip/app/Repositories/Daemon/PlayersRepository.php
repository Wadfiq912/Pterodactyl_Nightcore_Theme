<?php

namespace Pterodactyl\Repositories\Daemon;

use Psr\Http\Message\ResponseInterface;
use Pterodactyl\Contracts\Repository\Daemon\CommandRepositoryInterface;

class PlayersRepository extends BaseRepository implements CommandRepositoryInterface
{
    /**
     * @param array $data
     * @return ResponseInterface
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function operators(array $data): ResponseInterface
    {
        return $this->getHttpClient()->request('POST', 'server/minecraft/players/operators', [
            'json' => $data,
        ]);
    }

    /**
     * @param array $data
     * @return ResponseInterface
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function bans(array $data): ResponseInterface
    {
        return $this->getHttpClient()->request('POST', 'server/minecraft/players/bans', [
            'json' => $data,
        ]);
    }

    /**
     * Send a command to a server.
     *
     * @param string $command
     * @return \Psr\Http\Message\ResponseInterface
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function send_custom($command): ResponseInterface
    {
        return $this->getHttpClient()->request('POST', 'server/minecraft/players/command', [
            'json' => [
                'command' => $command,
            ],
        ]);
    }

    /**
     * Send a command to a server.
     *
     * @param string $command
     * @return \Psr\Http\Message\ResponseInterface
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function send(string $command): ResponseInterface
    {
        return $this->getHttpClient()->request('POST', 'server/command', [
            'json' => [
                'command' => $command,
            ],
        ]);
    }
}
